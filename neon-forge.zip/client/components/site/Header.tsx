import { Link, NavLink } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Film, PlayCircle } from "lucide-react";
import useActiveSection from "@/hooks/useActiveSection";

export default function Header() {
  const active = useActiveSection(["work", "services", "about", "contact", "reel"]);

  const linkClass = (id: string) =>
    `px-3 py-2 text-sm font-medium transition-colors ${
      active === id ? "text-primary" : "text-muted-foreground hover:text-foreground"
    }`;

  return (
    <header className="sticky top-0 z-40 w-full border-b border-border/60 bg-background/70 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <Link to="/" className="group inline-flex items-center gap-2" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
          <span className="relative h-9 w-9 overflow-hidden rounded-md bg-black">
            <img
              src="https://cdn.builder.io/api/v1/image/assets%2F67a2e7d075dd4c30bf2673dfdd8e401f%2Fda0c1a66b85744118702b4c047ffafc7?format=webp&width=800"
              alt="CUT logo"
              className="h-full w-full object-contain"
            />
          </span>
          <div className="leading-tight">
            <div className="text-sm text-muted-foreground">Haris Hamza</div>
            <div className="text-base font-semibold">Video Editor</div>
          </div>
        </Link>

        <nav className="hidden items-center gap-1 md:flex">
          <button onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} className={linkClass("home")}>
            Home
          </button>
          <a href="#work" className={linkClass("work")}>
            Work
          </a>
          <a href="#services" className={linkClass("services")}>
            Services
          </a>
          <a href="#about" className={linkClass("about")}>
            About
          </a>
          <a href="#contact" className={linkClass("contact")}>
            Contact
          </a>
        </nav>

        <div className="flex items-center gap-2">
          <a href="#reel">
            <Button variant="ghost" className="hidden md:inline-flex">
              <PlayCircle className="mr-2 h-4 w-4" /> Watch Reel
            </Button>
          </a>
          <a href="#contact">
            <Button className="bg-gradient-to-r from-primary via-secondary to-accent hover:opacity-90">
              Hire Me
            </Button>
          </a>
        </div>
      </div>
    </header>
  );
}
