import { Mail } from "lucide-react";

export default function Footer() {
  return (
    <footer className="border-t border-border/60">
      <div className="container py-10">
        <div className="flex flex-col items-center justify-between gap-6 md:flex-row">
          <div className="flex items-center gap-3">
            <img
              src="https://cdn.builder.io/api/v1/image/assets%2F67a2e7d075dd4c30bf2673dfdd8e401f%2Fda0c1a66b85744118702b4c047ffafc7?format=webp&width=800"
              alt="CUT logo"
              className="h-7 w-7 object-contain"
            />
            <p className="text-sm text-muted-foreground">
              © {new Date().getFullYear()} Haris Hamza — Video Editor
            </p>
          </div>
          <div className="flex items-center gap-4 text-muted-foreground">
            <a href="mailto:" aria-label="Email" className="hover:text-foreground">
              <Mail className="h-5 w-5" />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
