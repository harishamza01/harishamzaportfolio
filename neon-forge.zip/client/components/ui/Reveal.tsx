import React, { useRef, useEffect, useState } from "react";

interface RevealProps {
  children: React.ReactNode;
  className?: string;
  rootMargin?: string;
  threshold?: number;
  delay?: number; // ms
}

export default function Reveal({
  children,
  className = "",
  rootMargin = "0px 0px -10% 0px",
  threshold = 0.15,
  delay = 0,
}: RevealProps) {
  const ref = useRef<HTMLDivElement | null>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setTimeout(() => setVisible(true), delay);
            obs.unobserve(entry.target);
          }
        });
      },
      { root: null, rootMargin, threshold },
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [delay, rootMargin, threshold]);

  return (
    <div
      ref={ref}
      className={`${className} transition-all will-change-transform ${
        visible ? "opacity-100 translate-y-0 animate-fade-up" : "opacity-0 translate-y-6"
      }`}
      aria-hidden={!visible}
    >
      {children}
    </div>
  );
}
