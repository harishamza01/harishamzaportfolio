import { AspectRatio } from "@/components/ui/aspect-ratio";

export default function Showreel() {
  return (
    <section id="reel" className="container py-12 md:py-16">
      <div className="mx-auto max-w-5xl">
        <div className="mb-6 flex items-end justify-between">
          <h2 className="text-2xl font-semibold sm:text-3xl">Showreel</h2>
          <p className="text-sm text-muted-foreground">A quick taste of my style and pacing.</p>
        </div>
        <div className="overflow-hidden rounded-lg border border-border/60 bg-card shadow">
          <AspectRatio ratio={16 / 9}>
            <iframe
              title="Showreel"
              src="https://www.youtube.com/embed/nv9Q5PqL_bg?rel=0&modestbranding=1&color=white"
              className="h-full w-full"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
              referrerPolicy="strict-origin-when-cross-origin"
              allowFullScreen
            />
          </AspectRatio>
        </div>
      </div>
    </section>
  );
}
