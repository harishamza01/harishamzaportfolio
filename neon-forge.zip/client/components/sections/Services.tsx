import { Clapperboard, Palette, Sparkles } from "lucide-react";
import Reveal from "@/components/ui/Reveal";

const services = [
  {
    icon: Clapperboard,
    title: "Editing & Story",
    desc: "From rough cut to final edit. Narrative structure, pacing, and seamless transitions that keep viewers engaged.",
  },
  {
    icon: Palette,
    title: "Color Grading",
    desc: "Cinematic looks tailored to your brand. Balanced skin tones, punchy contrast and consistent mood across scenes.",
  },
  {
    icon: Sparkles,
    title: "Motion & GFX",
    desc: "Tasteful motion graphics, lower thirds, end cards and titles that enhance without distracting.",
  },
];

export default function Services() {
  return (
    <section id="services" className="container py-12 md:py-16">
      <div className="mx-auto max-w-5xl">
        <h2 className="text-2xl font-semibold sm:text-3xl">Services</h2>
        <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
          End-to-end post-production for commercials, social content, documentaries and music videos.
        </p>
        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {services.map((s, i) => (
            <Reveal key={s.title} delay={i * 100} className="">
              <div className="group rounded-xl border border-border/60 bg-card p-6 shadow transition-colors hover:border-primary/40">
                <s.icon className="h-6 w-6 text-primary" />
                <h3 className="mt-4 text-lg font-semibold">{s.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{s.desc}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
