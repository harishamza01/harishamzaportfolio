import Reveal from "@/components/ui/Reveal";

export default function About() {
  return (
    <section id="about" className="container py-12 md:py-16">
      <div className="mx-auto grid max-w-5xl items-center gap-8 md:grid-cols-2">
        <Reveal className="order-2 md:order-1" delay={80}>
          <h2 className="text-2xl font-semibold sm:text-3xl">About</h2>
          <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
            Hey, I’m <strong>Haris Hamza</strong> 👋
            <br /> I help brands and creators turn their raw clips into content people actually want to watch. I love taking messy footage and shaping it into something clean, engaging, and full of energy — whether that means adding motion graphics, polishing colors, or just making the story flow.
          </p>
          <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
            At the end of the day, my goal’s simple: create videos that stop the scroll and make your audience stick around.
          </p>
        </Reveal>
        <Reveal className="order-1 md:order-2" delay={160}>
          <div className="relative overflow-hidden rounded-xl border border-border/60 bg-card p-1 shadow">
            <div className="aspect-[4/5] w-full rounded-lg overflow-hidden bg-black">
              <img
                src="https://cdn.builder.io/api/v1/image/assets%2F67a2e7d075dd4c30bf2673dfdd8e401f%2Fefbb39de75084e6d9ec2e1c19cb9a389?format=webp&width=1600"
                alt="Haris Hamza portrait"
                className="h-full w-full object-cover"
                loading="lazy"
                width={800}
                height={1000}
              />
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
