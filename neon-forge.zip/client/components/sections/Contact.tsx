import { FormEvent } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

export default function Contact() {
  const onSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    const name = String(form.get("name") || "");
    const email = String(form.get("email") || "");
    const project = String(form.get("project") || "");
    const body = encodeURIComponent(
      `Hi Haris,\n\nName: ${name}\nEmail: ${email}\n\nProject Details:\n${project}`,
    );
    window.location.href = `mailto:harishamza947@gamil.com?subject=${encodeURIComponent(
      "New Project Inquiry",
    )}&body=${body}`;
  };

  return (
    <section id="contact" className="container py-12 md:py-16">
      <div className="mx-auto max-w-3xl">
        <h2 className="text-2xl font-semibold sm:text-3xl">Let’s Work Together</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          Tell me about your project. I’ll get back to you within 24 hours.
        </p>
        <form onSubmit={onSubmit} className="mt-8 grid gap-4">
          <div className="grid gap-2 sm:grid-cols-2">
            <div className="grid gap-2">
              <label htmlFor="name" className="text-sm">
                Name
              </label>
              <Input id="name" name="name" required placeholder="Your name" />
            </div>
            <div className="grid gap-2">
              <label htmlFor="email" className="text-sm">
                Email
              </label>
              <Input
                id="email"
                name="email"
                type="email"
                required
                placeholder="you@example.com"
              />
            </div>
          </div>
          <div className="grid gap-2">
            <label htmlFor="project" className="text-sm">
              Project details
            </label>
            <Textarea
              id="project"
              name="project"
              required
              rows={6}
              placeholder="What are you creating? Goals, timeline, budget…"
            />
          </div>
          <div className="flex items-center justify-between gap-4">
            <p className="text-xs text-muted-foreground">
              By submitting, you agree to be contacted about your project.
            </p>
            <Button type="submit" className="bg-gradient-to-r from-primary via-secondary to-accent hover:opacity-90">
              Send Inquiry
            </Button>
          </div>
        </form>
      </div>
    </section>
  );
}
