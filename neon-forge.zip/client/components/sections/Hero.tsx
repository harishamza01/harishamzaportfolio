import { Button } from "@/components/ui/button";
import { PlayCircle, Calendar } from "lucide-react";
import Reveal from "@/components/ui/Reveal";

export default function Hero() {
  return (
    <section className="relative overflow-hidden">
      <div className="absolute inset-0 -z-10">
        <div className="pointer-events-none absolute -inset-[40%] -z-10 rounded-full bg-[radial-gradient(circle_at_30%_20%,rgba(34,211,238,0.20),transparent_40%),radial-gradient(circle_at_70%_30%,rgba(217,70,239,0.20),transparent_40%),radial-gradient(circle_at_50%_80%,rgba(147,51,234,0.18),transparent_35%)] blur-3xl" />
      </div>
      <div className="container flex flex-col items-center gap-8 py-20 text-center md:py-28">
        <Reveal>
          <span className="inline-flex items-center rounded-full border border-border/60 bg-background/60 px-3 py-1 text-xs text-muted-foreground backdrop-blur">
            Available for freelance projects
          </span>
        </Reveal>

        <Reveal delay={80}>
          <h1 className="max-w-4xl bg-gradient-to-br from-white via-white to-white/70 bg-clip-text text-4xl font-extrabold tracking-tight text-transparent sm:text-5xl md:text-6xl pb-[13px] mb-[11px]">
            Turning your raw clips into scroll-stopping content
          </h1>
        </Reveal>

        <Reveal delay={160}>
          <p className="max-w-2xl text-balance text-base text-muted-foreground md:text-lg">
            I help brands and creators turn raw clips into scroll-stopping Reels, TikToks, and Shorts.
          </p>
        </Reveal>

        <div className="flex flex-col gap-3 sm:flex-row">
          <Reveal delay={240}>
            <a href="#reel">
              <Button size="lg" className="bg-gradient-to-r from-primary via-secondary to-accent hover:opacity-90">
                <PlayCircle className="mr-2 h-5 w-5" /> Watch Showreel
              </Button>
            </a>
          </Reveal>
          <Reveal delay={320}>
            <a href="#contact">
              <Button size="lg" className="bg-gradient-to-r from-primary via-secondary to-accent hover:opacity-90" variant="outline">
                <Calendar className="mr-2 h-5 w-5" /> Book a Call
              </Button>
            </a>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
