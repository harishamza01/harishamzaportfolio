import { useState } from "react";
import { Dialog, DialogContent, DialogTrigger, DialogTitle } from "@/components/ui/dialog";
import { AspectRatio } from "@/components/ui/aspect-ratio";
import Reveal from "@/components/ui/Reveal";

const projects = [
  {
    id: "Sagg3w7md34",
    title: "motion graphic edit with sleek & clean visuals",
    role: "Motion graphic Edit",
    yt: "i7mgdV9e6uY",
  },
  {
    id: "Cpo2aa1vx92",
    title: "Viral Short-form reel with strong hook & transitions ",
    role: "Viral Editing Edit reel",
    yt: "2loSVQeghiY",
  },
  {
    id: "Lxx7f9nqo11",
    title: "Short-form 3d editing style for social media",
    role: "trending 3d short",
    yt: "tHYLcXTYXeI",
  },
  {
    id: "Qaa0k9pwe56",
    title: "Website Show Reel Edit for apparel.io",
    role: "Website Edit",
    yt: "Kl1I_lrD0Ow",
  },
  {
    id: "Vvt2m0zze09",
    title: "Ad — Coffee Collective",
    role: "Edit · Grade",
    yt: "tAGnKpE4NCI",
  },
  {
    id: "Bbb8a1sse77",
    title: "Social — Travel Shorts",
    role: "Edit · GFX",
    yt: "2Vv-BfVoq4g",
  },
];

export default function Portfolio() {
  const [active, setActive] = useState<string | null>(null);
  return (
    <section id="work" className="container py-12 md:py-16">
      <div className="mx-auto max-w-5xl">
        <h2 className="text-2xl font-semibold sm:text-3xl">Portfolio</h2>
        <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
          A curated selection of recent edits. Click to watch.
        </p>
        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3 items-stretch">
          {projects.map((p, i) => (
            <Reveal key={p.id} delay={i * 80} className="h-full">
              <Dialog key={p.id} onOpenChange={(o) => !o && setActive(null)}>
                <DialogTrigger asChild>
                  <button
                    onClick={() => setActive(p.id)}
                    className="group h-72 sm:h-72 md:h-80 overflow-hidden rounded-xl border border-border/60 bg-card text-left shadow outline-none transition hover:border-primary/40 flex flex-col"
                  >
                    <div className="flex-1 overflow-hidden">
                      <img
                        src={`https://i.ytimg.com/vi/${p.yt}/hqdefault.jpg`}
                        alt={`${p.title} thumbnail`}
                        className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                        loading="lazy"
                      />
                    </div>
                    <div className="p-4 flex-none">
                      <div className="text-sm text-muted-foreground">{p.role}</div>
                      <div className="mt-1 font-medium">{p.title}</div>
                    </div>
                  </button>
                </DialogTrigger>
                <DialogContent className="max-w-4xl border-border bg-background p-0">
                  <DialogTitle className="sr-only">{p.title}</DialogTitle>
                  <AspectRatio ratio={16 / 9}>
                    <iframe
                      title={p.title}
                      src={`https://www.youtube.com/embed/${p.yt}?rel=0&modestbranding=1&color=white${active === p.id ? "&autoplay=1" : ""}`}
                      className="h-full w-full"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                      referrerPolicy="strict-origin-when-cross-origin"
                      allowFullScreen
                    />
                  </AspectRatio>
                </DialogContent>
              </Dialog>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
