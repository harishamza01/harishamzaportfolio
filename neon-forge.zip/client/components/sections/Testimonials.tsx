import Reveal from "@/components/ui/Reveal";

const items = [
  {
    quote:
      "Haris delivered a showreel for our brand that went beyond our expectations. The pacing, visuals, and overall flow captured our identity perfectly. We loved the final result and will definitely collaborate again.",
    author: "Apparel.Ai Team",
  },
  {
    quote:
      '"The UGC video edit was clean, trendy, and ready to post. It gave the content a professional yet natural feel that worked great for our campaign."',
    author: "E-commerce Brand (UGC Project)",
  },
];

export default function Testimonials() {
  return (
    <section className="container py-12 md:py-16">
      <div className="mx-auto max-w-5xl">
        <h2 className="text-2xl font-semibold sm:text-3xl">Testimonials</h2>
        <div className="mt-8 grid gap-5 md:grid-cols-3 justify-center items-center">
          {items.map((t, i) => (
            <Reveal key={t.author} delay={i * 80} className={i === 1 ? "flex flex-col" : ""}>
              <figure className={i === 0 ? "rounded-xl border border-border/60 bg-card p-3 shadow" : "rounded-xl border border-border/60 bg-card p-6 shadow flex flex-col justify-start items-start"}>
                <blockquote className="text-balance text-sm leading-relaxed text-muted-foreground">
                  “{t.quote}”
                </blockquote>
                <figcaption className="mt-4 text-sm font-medium">{t.author}</figcaption>
              </figure>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
