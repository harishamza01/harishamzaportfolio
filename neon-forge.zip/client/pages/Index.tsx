import Hero from "@/components/sections/Hero";
import Showreel from "@/components/sections/Showreel";
import Services from "@/components/sections/Services";
import Portfolio from "@/components/sections/Portfolio";
import Testimonials from "@/components/sections/Testimonials";
import About from "@/components/sections/About";
import Contact from "@/components/sections/Contact";

export default function Index() {
  return (
    <div className="flex flex-col">
      <Hero />
      <Showreel />
      <Services />
      <Portfolio />
      <Testimonials />
      <About />
      <Contact />
    </div>
  );
}
